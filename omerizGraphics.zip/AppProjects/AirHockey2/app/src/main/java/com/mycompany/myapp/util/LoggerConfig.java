package com.mycompany.myapp.util;

public class LoggerConfig{
	
	public static final boolean ON = true;
	
}
